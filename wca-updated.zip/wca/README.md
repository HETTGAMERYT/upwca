# 💬 WCA — WhatsApp Chat Analysis

An interactive [Streamlit](https://streamlit.io/) web application for analyzing exported WhatsApp `.txt` chat logs.

## ✨ What's New
- **Universal Export Parser**: Supports Android & iOS exports, 12-hour (including `\u202f` narrow no-break spaces) & 24-hour timestamps, 2-digit & 4-digit years, multi-line messages, and automatic separation of system notifications from participant messages.
- **Interactive Sidebar Filters**: Filter by specific participants, custom date ranges, message keywords, custom stopwords, and toggle `<Media omitted>` placeholders out of text statistics.
- **KPI Summary Dashboard**: Instant metrics for Total Messages, Active Participants, Total Words, Media Shared, Links Shared, and Total Emojis.
- **4 Organized Analytics Tabs**:
  1. **Activity & Timelines**: Top 25 active participants, chronological 24-hour distribution, daily message volume trend, day-of-week breakdown, and a Day × Hour activity heatmap.
  2. **Word Cloud & Content**: Stopword- and URL-cleaned Word Cloud, Top 15 most frequent words, Top 10 exact messages, and top shared link domains.
  3. **Emojis & Engagement**: Top 15 emojis with share percentages, plus per-participant engagement metrics (average words per message, media/links/emojis sent, conversation starters after ≥4h silence, and median reply time in minutes).
  4. **Data Explorer & Export**: Searchable message table, expandable system notifications viewer, and one-click CSV download.
- **Streamlit 1.36+ Compatibility**: Removed deprecated `deprecation.showPyplotGlobalUse` global state calls and explicitly passed figure objects to `st.pyplot(fig)`.

## 🚀 Quickstart

```bash
pip install -r requirements.txt
streamlit run streamlit.py
```

## 📤 Exporting a WhatsApp Chat
1. Open the individual or group chat in WhatsApp.
2. Tap **More options (⋮)** → **More** → **Export chat**.
3. Choose **Without media** to generate a `.txt` file, then upload it in the app.
