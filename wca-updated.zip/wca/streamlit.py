import re
import csv
from collections import Counter
from io import StringIO
import urllib.parse

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import seaborn as sns
import streamlit as st
from wordcloud import STOPWORDS, WordCloud

st.set_page_config(
    page_title="WhatsApp Chat Analyzer",
    page_icon="💬",
    layout="wide",
    initial_sidebar_state="expanded",
)

# Optional custom background / modern styling
def apply_custom_styling(show_bg: bool = False):
    bg_css = ""
    if show_bg:
        background_image = "https://www.teleosms.com/wp-content/uploads/2021/09/whatsapp-bg.jpg"
        bg_css = f"""
        .stApp {{
            background-image: linear-gradient(rgba(255, 255, 255, 0.90), rgba(255, 255, 255, 0.90)), url("{background_image}");
            background-size: cover;
            background-attachment: fixed;
        }}
        """
    st.markdown(
        f"""
        <style>
        {bg_css}
        div[data-testid="stMetric"] {{
            background-color: rgba(37, 211, 102, 0.08);
            border: 1px solid rgba(37, 211, 102, 0.25);
            padding: 12px 16px;
            border-radius: 10px;
        }}
        </style>
        """,
        unsafe_allow_html=True,
    )


# Regex patterns covering Android & iOS, 12h & 24h, 2-digit & 4-digit years, and Unicode spaces
LINE_PATTERNS = [
    # Android format: DD/MM/YY, HH:MM am/pm - Message (or 24h)
    re.compile(
        r"^(\d{1,2}/\d{1,2}/\d{2,4}),\s*(\d{1,2}:\d{2}(?::\d{2})?(?:[\s\u202f]*[apAP][mM])?)\s*-\s*(.+)$"
    ),
    # iOS bracketed format: [DD/MM/YY, HH:MM:SS AM/PM] Message
    re.compile(
        r"^\[(\d{1,2}/\d{1,2}/\d{2,4}),\s*(\d{1,2}:\d{2}(?::\d{2})?(?:[\s\u202f]*[apAP][mM])?)\]\s*(.+)$"
    ),
]

URL_PATTERN = re.compile(r"https?://\S+|www\.\S+", re.IGNORECASE)
MEDIA_PATTERN = re.compile(
    r"^<?(?:Media omitted|image omitted|video omitted|audio omitted|sticker omitted|GIF omitted|document omitted)>?$",
    re.IGNORECASE,
)
EMOJI_PATTERN = re.compile(
    "["
    "\U0001F600-\U0001F64F"  # Emoticons
    "\U0001F300-\U0001F5FF"  # Symbols & pictographs
    "\U0001F680-\U0001F6FF"  # Transport & map symbols
    "\U0001F1E0-\U0001F1FF"  # Flags
    "\U00002702-\U000027B0"
    "\U0001F900-\U0001F9FF"  # Supplemental symbols & pictographs
    "\U0001FA70-\U0001FAFF"  # Symbols & pictographs extended-A
    "\U00002600-\U000026FF"  # Misc symbols
    "]+",
    flags=re.UNICODE,
)

EXTRA_CHAT_STOPWORDS = {
    "media",
    "omitted",
    "null",
    "https",
    "http",
    "com",
    "www",
    "message",
    "deleted",
    "this",
    "was",
    "hai",
    "bhi",
    "aur",
    "toh",
    "nahi",
    "kya",
    "kar",
    "raha",
    "bhai",
}


def parse_time_to_minutes(time_str: str) -> tuple[int, str]:
    """Convert a 12h or 24h time string into minutes since midnight and meridiem."""
    cleaned = time_str.replace("\u202f", " ").strip()
    parts = cleaned.split()
    clock_part = parts[0]
    meridiem = parts[1].lower() if len(parts) > 1 else ""

    time_nums = list(map(int, clock_part.split(":")))
    hours, minutes = time_nums[0], time_nums[1]

    if meridiem:
        if meridiem == "pm" and hours != 12:
            hours += 12
        elif meridiem == "am" and hours == 12:
            hours = 0
    else:
        meridiem = "pm" if hours >= 12 else "am"

    return hours * 60 + minutes, meridiem


def contains_url(message: str) -> bool:
    return bool(URL_PATTERN.search(str(message)))


def extract_urls(message: str) -> list[str]:
    return URL_PATTERN.findall(str(message))


def extract_emojis(text: str) -> list[str]:
    clusters = EMOJI_PATTERN.findall(str(text))
    # Split multi-emoji clusters into individual characters (filtering variation selectors)
    return [ch for cluster in clusters for ch in cluster if ord(ch) not in (0xFE0F, 0x200D)]


@st.cache_data(show_spinner=False)
def parse_whatsapp_chat(raw_text: str) -> tuple[pd.DataFrame, pd.DataFrame]:
    """Parse raw WhatsApp export text into user messages DataFrame and system messages DataFrame."""
    records = []
    for line in raw_text.splitlines():
        line_stripped = line.strip("\r\n")
        if not line_stripped:
            continue

        matched = None
        for pat in LINE_PATTERNS:
            m = pat.match(line_stripped)
            if m:
                matched = m.groups()
                break

        if matched is None:
            if records:
                records[-1][2] += "\n" + line_stripped
        else:
            records.append([matched[0], matched[1], matched[2]])

    rows = []
    for date_str, time_str, body in records:
        minutes_total, meridiem = parse_time_to_minutes(time_str)
        hour = minutes_total // 60
        minute = minutes_total % 60
        clean_time = time_str.replace("\u202f", " ").strip().split()[0]

        if ":" in body:
            sender, msg = body.split(":", 1)
            sender = sender.strip()
            msg = msg.strip()
            is_system = False
        else:
            sender = "System"
            msg = body.strip()
            is_system = True

        rows.append(
            {
                "date_str": date_str.strip(),
                "time": clean_time,
                "meridiem": meridiem,
                "name": sender,
                "message": msg,
                "is_system": is_system,
                "time_in_min": minutes_total,
                "hour": hour,
                "minute": minute,
            }
        )

    df_all = pd.DataFrame(rows)
    if df_all.empty:
        return df_all, df_all

    # Parse dates flexibly (trying dayfirst=True first, falling back if needed)
    parsed_dates = pd.to_datetime(df_all["date_str"], dayfirst=True, errors="coerce")
    if parsed_dates.isna().mean() > 0.5:
        parsed_dates = pd.to_datetime(df_all["date_str"], dayfirst=False, errors="coerce")

    df_all["date"] = parsed_dates.dt.date
    df_all["datetime"] = pd.to_datetime(df_all["date"].astype(str)) + pd.to_timedelta(
        df_all["time_in_min"], unit="m"
    )
    df_all["day_name"] = parsed_dates.dt.day_name()
    df_all["month_year"] = parsed_dates.dt.to_period("M").astype(str)

    df_all["is_media"] = df_all["message"].apply(lambda x: bool(MEDIA_PATTERN.match(str(x).strip())))
    df_all["contains_link"] = df_all["message"].apply(contains_url)
    df_all["word_count"] = df_all["message"].apply(
        lambda x: 0 if MEDIA_PATTERN.match(str(x).strip()) else len(str(x).split())
    )
    df_all["char_count"] = df_all["message"].apply(
        lambda x: 0 if MEDIA_PATTERN.match(str(x).strip()) else len(str(x))
    )
    df_all["emojis"] = df_all["message"].apply(extract_emojis)
    df_all["emoji_count"] = df_all["emojis"].apply(len)

    df_users = df_all[~df_all["is_system"]].copy().reset_index(drop=True)
    df_system = df_all[df_all["is_system"]].copy().reset_index(drop=True)
    return df_users, df_system


def compute_engagement_metrics(df: pd.DataFrame) -> tuple[pd.Series, pd.Series]:
    """Calculate conversation starters (after >= 4 hr silence) and median response time (minutes)."""
    if df.empty or "datetime" not in df.columns:
        return pd.Series(dtype=int), pd.Series(dtype=float)

    df_sorted = df.dropna(subset=["datetime"]).sort_values("datetime").copy()
    df_sorted["time_diff_min"] = df_sorted["datetime"].diff().dt.total_seconds() / 60.0
    df_sorted["prev_sender"] = df_sorted["name"].shift(1)

    # Conversation starters: first message or message after >= 240 minutes (4 hours)
    starters = df_sorted[df_sorted["time_diff_min"].isna() | (df_sorted["time_diff_min"] >= 240)][
        "name"
    ].value_counts()

    # Replies: different sender within 60 minutes
    replies = df_sorted[
        (df_sorted["name"] != df_sorted["prev_sender"])
        & (df_sorted["time_diff_min"] > 0)
        & (df_sorted["time_diff_min"] <= 60)
    ]
    median_reply_min = replies.groupby("name")["time_diff_min"].median().round(1)
    return starters, median_reply_min


# ----------------- UI LAYOUT -----------------
st.sidebar.title("💬 WCA Controls")
show_bg = st.sidebar.toggle("WhatsApp Wallpaper Background", value=False)
apply_custom_styling(show_bg=show_bg)

st.title("💬 WhatsApp Chat Analysis")
st.caption("Upload an exported WhatsApp `.txt` chat file to explore participant activity, timelines, word clouds, emojis, and response patterns.")

uploaded_file = st.file_uploader("Choose a WhatsApp chat export (.txt)", type="txt")

if uploaded_file is not None:
    raw_text = uploaded_file.getvalue().decode("utf-8", errors="replace")
    df_chat, df_system = parse_whatsapp_chat(raw_text)

    if df_chat.empty:
        st.error(
            "Could not parse any chat messages from this file. Make sure it is a standard WhatsApp `.txt` chat export."
        )
        st.stop()

    # Sidebar Filters
    st.sidebar.header("🔍 Filters")
    all_participants = sorted(df_chat["name"].unique().tolist())
    selected_users = st.sidebar.multiselect(
        "Participants (leave empty for All)",
        options=all_participants,
        default=[],
    )

    valid_dates = df_chat["date"].dropna()
    if not valid_dates.empty:
        min_date, max_date = valid_dates.min(), valid_dates.max()
        date_range = st.sidebar.date_input(
            "Date Range",
            value=(min_date, max_date),
            min_value=min_date,
            max_value=max_date,
        )
    else:
        date_range = ()

    search_query = st.sidebar.text_input("Search Keyword in Messages", value="").strip()
    exclude_media_text = st.sidebar.checkbox("Exclude '<Media omitted>' in text charts", value=True)
    custom_stopwords_raw = st.sidebar.text_input(
        "Extra Stopwords (comma-separated)",
        value="",
        help="Add custom words to exclude from the Word Cloud and Top Words chart.",
    )

    # Apply filters
    df_filtered = df_chat.copy()
    if selected_users:
        df_filtered = df_filtered[df_filtered["name"].isin(selected_users)]
    if isinstance(date_range, (list, tuple)) and len(date_range) == 2:
        start_d, end_d = date_range
        df_filtered = df_filtered[(df_filtered["date"] >= start_d) & (df_filtered["date"] <= end_d)]
    if search_query:
        df_filtered = df_filtered[
            df_filtered["message"].str.contains(re.escape(search_query), case=False, na=False)
        ]

    if df_filtered.empty:
        st.warning("No messages match the selected filters. Try broadening your filter criteria.")
        st.stop()

    # Top-level KPI Metrics
    total_messages = len(df_filtered)
    active_users = df_filtered["name"].nunique()
    total_words = int(df_filtered["word_count"].sum())
    total_media = int(df_filtered["is_media"].sum())
    total_links = int(df_filtered["contains_link"].sum())
    total_emojis = int(df_filtered["emoji_count"].sum())

    kpi1, kpi2, kpi3, kpi4, kpi5, kpi6 = st.columns(6)
    kpi1.metric("Total Messages", f"{total_messages:,}")
    kpi2.metric("Participants", f"{active_users:,}")
    kpi3.metric("Total Words", f"{total_words:,}")
    kpi4.metric("Media Shared", f"{total_media:,}")
    kpi5.metric("Messages w/ Links", f"{total_links:,}")
    kpi6.metric("Total Emojis", f"{total_emojis:,}")

    tab_activity, tab_content, tab_engagement, tab_data = st.tabs(
        [
            "📊 Activity & Timelines",
            "☁️ Word Cloud & Content",
            "😀 Emojis & Engagement",
            "🗂️ Data Explorer & Export",
        ]
    )

    # ----------------- TAB 1: ACTIVITY & TIMELINES -----------------
    with tab_activity:
        col_left, col_right = st.columns(2)

        with col_left:
            st.subheader("Top 25 Most Active Participants")
            top_users = df_filtered["name"].value_counts().head(25)
            fig_users, ax_users = plt.subplots(figsize=(8, 5))
            sns.barplot(
                x=top_users.values,
                y=top_users.index,
                hue=top_users.index,
                palette="viridis",
                legend=False,
                ax=ax_users,
            )
            ax_users.set_xlabel("Message Count")
            ax_users.set_ylabel("Participant")
            ax_users.set_title("Messages per Participant")
            plt.tight_layout()
            st.pyplot(fig_users)
            plt.close(fig_users)

        with col_right:
            st.subheader("Activity by Hour of Day (24h)")
            hour_counts = df_filtered["hour"].value_counts().reindex(range(24), fill_value=0)
            fig_hour, ax_hour = plt.subplots(figsize=(8, 5))
            sns.barplot(
                x=[f"{h:02d}:00" for h in hour_counts.index],
                y=hour_counts.values,
                color="#25D366",
                ax=ax_hour,
            )
            ax_hour.set_xlabel("Hour of Day")
            ax_hour.set_ylabel("Message Count")
            ax_hour.set_title("Hourly Message Distribution")
            plt.xticks(rotation=45)
            plt.tight_layout()
            st.pyplot(fig_hour)
            plt.close(fig_hour)

        st.divider()
        col_t1, col_t2 = st.columns(2)

        with col_t1:
            st.subheader("Daily Message Volume")
            daily_counts = df_filtered.groupby("date").size()
            if not daily_counts.empty:
                st.line_chart(daily_counts)

        with col_t2:
            st.subheader("Activity by Day of Week")
            day_order = [
                "Monday",
                "Tuesday",
                "Wednesday",
                "Thursday",
                "Friday",
                "Saturday",
                "Sunday",
            ]
            day_counts = df_filtered["day_name"].value_counts().reindex(day_order, fill_value=0)
            fig_day, ax_day = plt.subplots(figsize=(8, 4))
            sns.barplot(
                x=day_counts.index,
                y=day_counts.values,
                hue=day_counts.index,
                palette="crest",
                legend=False,
                ax=ax_day,
            )
            ax_day.set_xlabel("Day of Week")
            ax_day.set_ylabel("Message Count")
            plt.xticks(rotation=30)
            plt.tight_layout()
            st.pyplot(fig_day)
            plt.close(fig_day)

        st.subheader("Weekly Activity Heatmap (Day × Hour)")
        heatmap_pivot = (
            df_filtered.pivot_table(
                index="day_name",
                columns="hour",
                values="message",
                aggfunc="count",
                fill_value=0,
            )
            .reindex(day_order, fill_value=0)
            .reindex(columns=range(24), fill_value=0)
        )
        fig_heat, ax_heat = plt.subplots(figsize=(12, 4))
        sns.heatmap(heatmap_pivot, cmap="YlGnBu", linewidths=0.3, ax=ax_heat)
        ax_heat.set_xlabel("Hour of Day (0–23)")
        ax_heat.set_ylabel("Day of Week")
        plt.tight_layout()
        st.pyplot(fig_heat)
        plt.close(fig_heat)

    # ----------------- TAB 2: WORD CLOUD & CONTENT -----------------
    with tab_content:
        df_text = df_filtered[~df_filtered["is_media"]] if exclude_media_text else df_filtered

        extra_stops = {
            w.strip().lower() for w in custom_stopwords_raw.split(",") if w.strip()
        }
        all_stopwords = set(STOPWORDS) | EXTRA_CHAT_STOPWORDS | extra_stops

        # Clean URLs from text before building word cloud
        cleaned_tokens = []
        for msg in df_text["message"].dropna().astype(str):
            no_urls = URL_PATTERN.sub("", msg)
            words = re.findall(r"[A-Za-z\u0900-\u097F]{2,}", no_urls.lower())
            cleaned_tokens.extend([w for w in words if w not in all_stopwords])

        col_wc, col_words = st.columns([3, 2])

        with col_wc:
            st.subheader("Word Cloud of Messages")
            if cleaned_tokens:
                wc_text = " ".join(cleaned_tokens)
                wordcloud = WordCloud(
                    width=800,
                    height=450,
                    background_color="white",
                    colormap="Dark2",
                    stopwords=all_stopwords,
                    collocations=False,
                ).generate(wc_text)
                fig_wc, ax_wc = plt.subplots(figsize=(10, 5.5))
                ax_wc.imshow(wordcloud, interpolation="bilinear")
                ax_wc.axis("off")
                plt.tight_layout()
                st.pyplot(fig_wc)
                plt.close(fig_wc)
            else:
                st.info("Not enough non-stopword text to generate a Word Cloud.")

        with col_words:
            st.subheader("Top 15 Most Used Words")
            if cleaned_tokens:
                top_words = Counter(cleaned_tokens).most_common(15)
                words_df = pd.DataFrame(top_words, columns=["Word", "Count"])
                fig_tw, ax_tw = plt.subplots(figsize=(6, 5.5))
                sns.barplot(
                    data=words_df,
                    x="Count",
                    y="Word",
                    hue="Word",
                    palette="mako",
                    legend=False,
                    ax=ax_tw,
                )
                ax_tw.set_title("Most Frequent Words")
                plt.tight_layout()
                st.pyplot(fig_tw)
                plt.close(fig_tw)

        st.divider()
        col_common, col_links = st.columns(2)

        with col_common:
            st.subheader("Top 10 Most Common Exact Messages")
            common_msgs = df_text["message"].value_counts().head(10)
            if not common_msgs.empty:
                fig_cm, ax_cm = plt.subplots(figsize=(8, 4.5))
                sns.barplot(
                    x=common_msgs.values,
                    y=[m[:40] + ("..." if len(m) > 40 else "") for m in common_msgs.index],
                    color="#128C7E",
                    ax=ax_cm,
                )
                ax_cm.set_xlabel("Frequency")
                ax_cm.set_ylabel("Message")
                plt.tight_layout()
                st.pyplot(fig_cm)
                plt.close(fig_cm)

        with col_links:
            st.subheader("Shared Links & Top Domains")
            all_urls = [
                u for msg in df_filtered[df_filtered["contains_link"]]["message"] for u in extract_urls(msg)
            ]
            if all_urls:
                domains = [urllib.parse.urlparse(u).netloc.lower() or u for u in all_urls]
                domain_df = pd.DataFrame(
                    Counter(domains).most_common(10), columns=["Domain", "Count"]
                )
                st.dataframe(domain_df, use_container_width=True, hide_index=True)
            else:
                st.info("No URLs found in the filtered messages.")

    # ----------------- TAB 3: EMOJIS & ENGAGEMENT -----------------
    with tab_engagement:
        col_em, col_eng = st.columns(2)

        with col_em:
            st.subheader("Top Emojis Used")
            all_emojis = [e for em_list in df_filtered["emojis"] for e in em_list]
            if all_emojis:
                emoji_counts = Counter(all_emojis).most_common(15)
                emoji_df = pd.DataFrame(emoji_counts, columns=["Emoji", "Count"])
                emoji_df["Share (%)"] = (emoji_df["Count"] / len(all_emojis) * 100).round(1)
                st.dataframe(emoji_df, use_container_width=True, hide_index=True)
            else:
                st.info("No emojis detected in the filtered messages.")

        with col_eng:
            st.subheader("Participant Engagement Breakdown")
            user_stats = (
                df_filtered.groupby("name")
                .agg(
                    Messages=("message", "count"),
                    Words=("word_count", "sum"),
                    Avg_Words_Per_Msg=("word_count", "mean"),
                    Media_Sent=("is_media", "sum"),
                    Links_Sent=("contains_link", "sum"),
                    Emojis_Sent=("emoji_count", "sum"),
                )
                .sort_values("Messages", ascending=False)
            )
            user_stats["Avg_Words_Per_Msg"] = user_stats["Avg_Words_Per_Msg"].round(1)

            starters, median_reply = compute_engagement_metrics(df_filtered)
            user_stats["Conv_Starters"] = user_stats.index.map(starters).fillna(0).astype(int)
            user_stats["Median_Reply_Min"] = user_stats.index.map(median_reply)

            st.dataframe(
                user_stats.reset_index().rename(columns={"name": "Participant"}),
                use_container_width=True,
                hide_index=True,
            )

    # ----------------- TAB 4: DATA EXPLORER & EXPORT -----------------
    with tab_data:
        st.subheader("Parsed Chat Dataset")
        export_cols = [
            "date",
            "time",
            "meridiem",
            "name",
            "message",
            "hour",
            "day_name",
            "word_count",
            "is_media",
            "contains_link",
            "emoji_count",
        ]
        st.dataframe(df_filtered[export_cols], use_container_width=True, height=400)

        updated_output = StringIO()
        df_filtered[export_cols].to_csv(updated_output, index=False)
        st.download_button(
            label="⬇️ Download Enriched CSV",
            data=updated_output.getvalue(),
            file_name="updated_whatsapp_chat_dataset.csv",
            mime="text/csv",
        )

        if not df_system.empty:
            with st.expander(f"View System Notifications ({len(df_system)} events)"):
                st.dataframe(
                    df_system[["date_str", "time", "meridiem", "message"]],
                    use_container_width=True,
                    hide_index=True,
                )
else:
    st.info("👆 Upload a `.txt` WhatsApp chat export file above to begin analysis.")
